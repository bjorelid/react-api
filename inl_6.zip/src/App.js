import ApiRequest from './ApiRequest';
import './App.css';

function App() {
  return (
    <div className="App">
      <ApiRequest />
    </div>
  );
}

export default App;
